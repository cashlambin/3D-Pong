// Game class for the 3D Pong game
import * as THREE from 'three';
import { io } from 'socket.io-client';

export class Game {
    constructor(ui) {
        this.ui = ui;
        this.running = false;
        this.playerName = 'Player';
        this.scores = { player: 0, opponent: 0 };
        
        // Game settings
        this.settings = {
            maxScore: 10,
            paddleSpeed: 0.15,
            initialBallSpeed: 0.1,
            ballSpeedIncrease: 0.005,
            courtWidth: 20,
            courtDepth: 30,
            courtHeight: 10,
            paddleWidth: 4,
            paddleHeight: 3,
            paddleDepth: 0.5,
            ballRadius: 0.5
        };
        
        // Socket.io connection
        this.socket = null;
        
        // Three.js components
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.lights = [];
        
        // Game objects
        this.court = null;
        this.playerPaddle = null;
        this.opponentPaddle = null;
        this.ball = null;
        
        // Game state
        this.ballDirection = new THREE.Vector3(0, 0, 0);
        this.ballSpeed = this.settings.initialBallSpeed;
        this.lastFrameTime = 0;
        
        // Controls state
        this.mousePosition = { x: 0, y: 0 };
        this.keys = { up: false, down: false, left: false, right: false };
        
        // Animation frame ID for cancellation
        this.animationFrameId = null;
    }
    
    // Initialize the game
    async init() {
        try {
            // Initialize Three.js components
            this.initThreeJS();
            
            // Create game objects
            this.createCourt();
            this.createPaddles();
            this.createBall();
            
            // Initialize socket connection
            this.initSocketConnection();
            
            // Set up camera position
            this.camera.position.set(0, 15, 20);
            this.camera.lookAt(0, 0, 0);
            
            return Promise.resolve();
        } catch (error) {
            return Promise.reject(error);
        }
    }
    
    // Initialize Three.js components
    initThreeJS() {
        // Create scene
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0x000000);
        
        // Create camera
        const aspect = window.innerWidth / window.innerHeight;
        this.camera = new THREE.PerspectiveCamera(75, aspect, 0.1, 1000);
        
        // Create renderer
        this.renderer = new THREE.WebGLRenderer({ 
            canvas: document.getElementById('game-canvas'),
            antialias: true 
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        
        // Add lights
        this.addLights();
        
        // Handle window resize
        this.handleResize();
    }
    
    // Add lights to the scene
    addLights() {
        // Ambient light
        const ambientLight = new THREE.AmbientLight(0x404040, 0.5);
        this.scene.add(ambientLight);
        this.lights.push(ambientLight);
        
        // Directional light
        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(0, 10, 10);
        this.scene.add(directionalLight);
        this.lights.push(directionalLight);
        
        // Point lights for atmosphere
        const colors = [0x00ffff, 0xff00ff, 0xffff00];
        
        for (let i = 0; i < colors.length; i++) {
            const pointLight = new THREE.PointLight(colors[i], 0.5, 20);
            pointLight.position.set(
                (i - 1) * 10,
                5,
                -5
            );
            this.scene.add(pointLight);
            this.lights.push(pointLight);
        }
    }
    
    // Create the game court
    createCourt() {
        const { courtWidth, courtDepth, courtHeight } = this.settings;
        
        // Court geometry
        const courtGeometry = new THREE.BoxGeometry(courtWidth, 0.1, courtDepth);
        
        // Court material with grid texture
        const courtMaterial = new THREE.MeshStandardMaterial({
            color: 0x0088ff,
            metalness: 0.2,
            roughness: 0.5,
            emissive: 0x001133,
            wireframe: false
        });
        
        // Create court mesh
        this.court = new THREE.Mesh(courtGeometry, courtMaterial);
        this.scene.add(this.court);
        
        // Add court walls
        this.addCourtWalls();
        
        // Add center line
        this.addCenterLine();
    }
    
    // Add walls to the court
    addCourtWalls() {
        const { courtWidth, courtDepth, courtHeight } = this.settings;
        
        // Wall material
        const wallMaterial = new THREE.MeshStandardMaterial({
            color: 0x00ffff,
            transparent: true,
            opacity: 0.3,
            metalness: 0.8,
            roughness: 0.2
        });
        
        // Left wall
        const leftWallGeometry = new THREE.BoxGeometry(0.1, courtHeight, courtDepth);
        const leftWall = new THREE.Mesh(leftWallGeometry, wallMaterial);
        leftWall.position.set(-courtWidth/2, courtHeight/2, 0);
        this.scene.add(leftWall);
        
        // Right wall
        const rightWallGeometry = new THREE.BoxGeometry(0.1, courtHeight, courtDepth);
        const rightWall = new THREE.Mesh(rightWallGeometry, wallMaterial);
        rightWall.position.set(courtWidth/2, courtHeight/2, 0);
        this.scene.add(rightWall);
        
        // Top wall
        const topWallGeometry = new THREE.BoxGeometry(courtWidth, 0.1, courtDepth);
        const topWall = new THREE.Mesh(topWallGeometry, wallMaterial);
        topWall.position.set(0, courtHeight, 0);
        this.scene.add(topWall);
    }
    
    // Add center line to the court
    addCenterLine() {
        const { courtWidth } = this.settings;
        
        // Center line material
        const lineMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff });
        
        // Center line geometry
        const lineGeometry = new THREE.BoxGeometry(courtWidth, 0.1, 0.1);
        const centerLine = new THREE.Mesh(lineGeometry, lineMaterial);
        centerLine.position.set(0, 0.06, 0);
        this.scene.add(centerLine);
    }
    
    // Create player and opponent paddles
    createPaddles() {
        const { paddleWidth, paddleHeight, paddleDepth, courtDepth } = this.settings;
        
        // Paddle geometry
        const paddleGeometry = new THREE.BoxGeometry(paddleWidth, paddleHeight, paddleDepth);
        
        // Player paddle material
        const playerPaddleMaterial = new THREE.MeshStandardMaterial({
            color: 0x00ffff,
            metalness: 0.5,
            roughness: 0.2,
            emissive: 0x003333
        });
        
        // Opponent paddle material
        const opponentPaddleMaterial = new THREE.MeshStandardMaterial({
            color: 0xff00ff,
            metalness: 0.5,
            roughness: 0.2,
            emissive: 0x330033
        });
        
        // Create player paddle
        this.playerPaddle = new THREE.Mesh(paddleGeometry, playerPaddleMaterial);
        this.playerPaddle.position.set(0, paddleHeight/2, courtDepth/2 - paddleDepth/2);
        this.scene.add(this.playerPaddle);
        
        // Create opponent paddle
        this.opponentPaddle = new THREE.Mesh(paddleGeometry, opponentPaddleMaterial);
        this.opponentPaddle.position.set(0, paddleHeight/2, -courtDepth/2 + paddleDepth/2);
        this.scene.add(this.opponentPaddle);
    }
    
    // Create the ball
    createBall() {
        const { ballRadius } = this.settings;
        
        // Ball geometry
        const ballGeometry = new THREE.SphereGeometry(ballRadius, 32, 32);
        
        // Ball material
        const ballMaterial = new THREE.MeshStandardMaterial({
            color: 0xffff00,
            metalness: 0.7,
            roughness: 0.2,
            emissive: 0x333300
        });
        
        // Create ball mesh
        this.ball = new THREE.Mesh(ballGeometry, ballMaterial);
        this.ball.position.set(0, ballRadius, 0);
        this.scene.add(this.ball);
    }
    
    // Initialize socket.io connection
    initSocketConnection() {
        this.socket = io();
        
        // Connection event
        this.socket.on('connect', () => {
            console.log('Connected to server with ID:', this.socket.id);
        });
        
        // Disconnection event
        this.socket.on('disconnect', () => {
            console.log('Disconnected from server');
            this.ui.showStatus('Disconnected from server. Please refresh the page.');
        });
        
        // Game events
        this.socket.on('gameStart', (data) => {
            this.ui.showStatus('Game started!');
        });
        
        this.socket.on('gameUpdate', (data) => {
            // Update opponent paddle position
            if (data.opponentPaddle) {
                this.opponentPaddle.position.x = data.opponentPaddle.x;
                this.opponentPaddle.position.y = data.opponentPaddle.y;
            }
            
            // Update ball position if server is authoritative
            if (data.ball && !this.isHost) {
                this.ball.position.copy(data.ball.position);
                this.ballDirection.copy(data.ball.direction);
                this.ballSpeed = data.ball.speed;
            }
            
            // Update scores
            if (data.scores) {
                this.scores = data.scores;
                this.ui.updateScore(this.scores.player, this.scores.opponent);
            }
        });
        
        this.socket.on('playerJoined', (data) => {
            this.ui.showStatus(`${data.playerName} joined the game!`);
        });
        
        this.socket.on('playerLeft', (data) => {
            this.ui.showStatus(`${data.playerName} left the game.`);
        });
        
        this.socket.on('gameOver', (data) => {
            this.running = false;
            const winner = data.winner === this.socket.id ? 'You' : 'Opponent';
            this.ui.showStatus(`Game Over! ${winner} won!`, 0);
            
            // Reset game after delay
            setTimeout(() => {
                this.reset();
                this.ui.reset();
            }, 5000);
        });
    }
    
    // Start the game
    start() {
        if (this.running) return;
        
        this.running = true;
        this.resetBall();
        
        // Notify server
        this.socket.emit('playerReady', {
            playerName: this.playerName
        });
        
        // Start game loop
        this.lastFrameTime = performance.now();
        this.gameLoop();
    }
    
    // Game loop
    gameLoop() {
        if (!this.running) return;
        
        const currentTime = performance.now();
        const deltaTime = (currentTime - this.lastFrameTime) / 1000; // Convert to seconds
        this.lastFrameTime = currentTime;
        
        // Update game state
        this.update(deltaTime);
        
        // Render scene
        this.renderer.render(this.scene, this.camera);
        
        // Continue loop
        this.animationFrameId = requestAnimationFrame(() => this.gameLoop());
    }
    
    // Update game state
    update(deltaTime) {
        // Update paddle position based on input
        this.updatePaddlePosition(deltaTime);
        
        // Update ball position
        this.updateBallPosition(deltaTime);
        
        // Check for collisions
        this.checkCollisions();
        
        // Send game state to server
        this.sendGameState();
    }
    
    // Update paddle position based on input
    updatePaddlePosition(deltaTime) {
        const { paddleSpeed, courtWidth, paddleWidth } = this.settings;
        const maxX = (courtWidth - paddleWidth) / 2;
        
        // Mouse control
        if (this.mousePosition.x !== 0) {
            // Convert mouse position to paddle position
            const paddleX = (this.mousePosition.x * 2 - 1) * maxX;
            this.playerPaddle.position.x = THREE.MathUtils.clamp(paddleX, -maxX, maxX);
        }
        
        // Keyboard control
        if (this.keys.left) {
            this.playerPaddle.position.x -= paddleSpeed * deltaTime * 60;
        }
        if (this.keys.right) {
            this.playerPaddle.position.x += paddleSpeed * deltaTime * 60;
        }
        
        // Clamp paddle position
        this.playerPaddle.position.x = THREE.MathUtils.clamp(
            this.playerPaddle.position.x, 
            -maxX, 
            maxX
        );
    }
    
    // Update ball position
    updateBallPosition(deltaTime) {
        // Move ball based on direction and speed
        this.ball.position.x += this.ballDirection.x * this.ballSpeed * deltaTime * 60;
        this.ball.position.y += this.ballDirection.y * this.ballSpeed * deltaTime * 60;
        this.ball.position.z += this.ballDirection.z * this.ballSpeed * deltaTime * 60;
        
        // Add ball rotation for visual effect
        this.ball.rotation.x += this.ballDirection.z * 0.1;
        this.ball.rotation.z -= this.ballDirection.x * 0.1;
    }
    
    // Check for collisions
    checkCollisions() {
        const { 
            courtWidth, courtHeight, courtDepth, 
            paddleWidth, paddleHeight, paddleDepth,
            ballRadius
        } = this.settings;
        
        const ball = this.ball;
        const halfCourtWidth = courtWidth / 2;
        const halfCourtDepth = courtDepth / 2;
        
        // Wall collisions (left/right)
        if (ball.position.x - ballRadius < -halfCourtWidth) {
            ball.position.x = -halfCourtWidth + ballRadius;
            this.ballDirection.x *= -1;
            this.playSound('wall');
        } else if (ball.position.x + ballRadius > halfCourtWidth) {
            ball.position.x = halfCourtWidth - ballRadius;
            this.ballDirection.x *= -1;
            this.playSound('wall');
        }
        
        // Wall collisions (top/bottom)
        if (ball.position.y - ballRadius < 0) {
            ball.position.y = ballRadius;
            this.ballDirection.y *= -1;
            this.playSound('wall');
        } else if (ball.position.y + ballRadius > courtHeight) {
            ball.position.y = courtHeight - ballRadius;
            this.ballDirection.y *= -1;
            this.playSound('wall');
        }
        
        // Paddle collisions
        this.checkPaddleCollision(this.playerPaddle, 1);
        this.checkPaddleCollision(this.opponentPaddle, -1);
        
        // Goal collisions
        if (ball.position.z - ballRadius > halfCourtDepth) {
            // Opponent scores
            this.scores.opponent++;
            this.ui.updateScore(this.scores.player, this.scores.opponent);
            this.ui.showStatus('Opponent scored!');
            this.resetBall();
            this.playSound('score');
            
            // Check for game over
            this.checkGameOver();
        } else if (ball.position.z + ballRadius < -halfCourtDepth) {
            // Player scores
            this.scores.player++;
            this.ui.updateScore(this.scores.player, this.scores.opponent);
            this.ui.showStatus('You scored!');
            this.resetBall();
            this.playSound('score');
            
            // Check for game over
            this.checkGameOver();
        }
    }
    
    // Check for paddle collision
    checkPaddleCollision(paddle, direction) {
        const { 
            paddleWidth, paddleHeight, paddleDepth,
            ballRadius
        } = this.settings;
        
        const ball = this.ball;
        const halfPaddleWidth = paddleWidth / 2;
        const halfPaddleDepth = paddleDepth / 2;
        
        // Check if ball is in front of paddle
        if (direction > 0 && ball.position.z + ballRadius > paddle.position.z - halfPaddleDepth ||
            direction < 0 && ball.position.z - ballRadius < paddle.position.z + halfPaddleDepth) {
            
            // Check if ball is within paddle width and height
            if (ball.position.x > paddle.position.x - halfPaddleWidth &&
                ball.position.x < paddle.position.x + halfPaddleWidth &&
                ball.position.y > paddle.position.y - paddleHeight / 2 &&
                ball.position.y < paddle.position.y + paddleHeight / 2) {
                
                // Collision detected
                if (direction > 0) {
                    ball.position.z = paddle.position.z - halfPaddleDepth - ballRadius;
                } else {
                    ball.position.z = paddle.position.z + halfPaddleDepth + ballRadius;
                }
                
                // Reflect ball direction
                this.ballDirection.z *= -1;
                
                // Add some variation based on where the ball hit the paddle
                const hitPosition = (ball.position.x - paddle.position.x) / halfPaddleWidth;
                this.ballDirection.x = hitPosition * 0.5;
                
                // Normalize direction vector
                const length = Math.sqrt(
                    this.ballDirection.x * this.ballDirection.x + 
                    this.ballDirection.y * this.ballDirection.y + 
                    this.ballDirection.z * this.ballDirection.z
                );
                
                this.ballDirection.x /= length;
                this.ballDirection.y /= length;
                this.ballDirection.z /= length;
                
                // Increase ball speed
                this.ballSpeed += this.settings.ballSpeedIncrease;
                
                // Play sound
                this.playSound('paddle');
            }
        }
    }
    
    // Reset ball position and direction
    resetBall() {
        this.ball.position.set(0, this.settings.ballRadius, 0);
        
        // Random direction
        const angle = Math.random() * Math.PI * 2;
        const z = Math.random() > 0.5 ? 0.7 : -0.7;
        
        this.ballDirection.set(
            Math.cos(angle) * 0.3,
            Math.sin(angle) * 0.3,
            z
        );
        
        // Normalize direction
        const length = Math.sqrt(
            this.ballDirection.x * this.ballDirection.x + 
            this.ballDirection.y * this.ballDirection.y + 
            this.ballDirection.z * this.ballDirection.z
        );
        
        this.ballDirection.x /= length;
        this.ballDirection.y /= length;
        this.ballDirection.z /= length;
        
        // Reset ball speed
        this.ballSpeed = this.settings.initialBallSpeed;
    }
    
    // Check if game is over
    checkGameOver() {
        if (this.scores.player >= this.settings.maxScore || 
            this.scores.opponent >= this.settings.maxScore) {
            
            const winner = this.scores.player > this.scores.opponent ? 'player' : 'opponent';
            
            // Emit game over event
            this.socket.emit('gameOver', {
                winner: winner
            });
            
            // Show game over message
            const winnerText = winner === 'player' ? 'You' : 'Opponent';
            this.ui.showStatus(`Game Over! ${winnerText} won!`, 0);
            
            // Stop game loop
            this.running = false;
            
            // Reset game after delay
            setTimeout(() => {
                this.reset();
                this.ui.reset();
            }, 5000);
        }
    }
    
    // Send game state to server
    sendGameState() {
        if (!this.socket) return;
        
        this.socket.emit('gameUpdate', {
            playerPaddle: {
                x: this.playerPaddle.position.x,
                y: this.playerPaddle.position.y
            },
            ball: {
                position: this.ball.position,
                direction: this.ballDirection,
                speed: this.ballSpeed
            },
            scores: this.scores
        });
    }
    
    // Play sound effect
    playSound(type) {
        // Sound effects would be implemented here
        // For now, just log the sound type
        console.log('Play sound:', type);
    }
    
    // Handle mouse movement
    handleMouseMove(event) {
        // Calculate normalized mouse position (0 to 1)
        this.mousePosition.x = event.clientX / window.innerWidth;
    }
    
    // Handle key down event
    handleKeyDown(event) {
        switch(event.key) {
            case 'ArrowLeft':
                this.keys.left = true;
                break;
            case 'ArrowRight':
                this.keys.right = true;
                break;
            case 'ArrowUp':
                this.keys.up = true;
                break;
            case 'ArrowDown':
                this.keys.down = true;
                break;
        }
    }
    
    // Handle key up event
    handleKeyUp(event) {
        switch(event.key) {
            case 'ArrowLeft':
                this.keys.left = false;
                break;
            case 'ArrowRight':
                this.keys.right = false;
                break;
            case 'ArrowUp':
                this.keys.up = false;
                break;
            case 'ArrowDown':
                this.keys.down = false;
                break;
        }
    }
    
    // Handle window resize
    handleResize() {
        if (!this.camera || !this.renderer) return;
        
        // Update camera aspect ratio
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        
        // Update renderer size
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }
    
    // Set player name
    setPlayerName(name) {
        this.playerName = name;
    }
    
    // Check if game is running
    isRunning() {
        return this.running;
    }
    
    // Reset game state
    reset() {
        this.running = false;
        this.scores = { player: 0, opponent: 0 };
        this.resetBall();
        
        // Reset paddles
        const { courtDepth, paddleHeight, paddleDepth } = this.settings;
        this.playerPaddle.position.set(0, paddleHeight/2, courtDepth/2 - paddleDepth/2);
        this.opponentPaddle.position.set(0, paddleHeight/2, -courtDepth/2 + paddleDepth/2);
        
        // Cancel animation frame
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
        }
    }
}
