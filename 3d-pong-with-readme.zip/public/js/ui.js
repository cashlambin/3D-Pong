// UI Manager for the 3D Pong game
export class UI {
    constructor() {
        // Cache DOM elements
        this.loadingScreen = document.getElementById('loading-screen');
        this.menuScreen = document.getElementById('menu-screen');
        this.instructionsScreen = document.getElementById('instructions-screen');
        this.gameUI = document.getElementById('game-ui');
        this.playerScore = document.getElementById('player-score');
        this.opponentScore = document.getElementById('opponent-score');
        this.gameStatus = document.getElementById('game-status');
    }

    // Loading screen methods
    showLoadingScreen() {
        this.loadingScreen.classList.remove('hidden');
    }

    hideLoadingScreen() {
        this.loadingScreen.classList.add('hidden');
    }

    // Menu screen methods
    showMenuScreen() {
        this.menuScreen.classList.remove('hidden');
    }

    hideMenuScreen() {
        this.menuScreen.classList.add('hidden');
    }

    // Instructions screen methods
    showInstructionsScreen() {
        this.instructionsScreen.classList.remove('hidden');
    }

    hideInstructionsScreen() {
        this.instructionsScreen.classList.add('hidden');
    }

    // Game UI methods
    showGameUI() {
        this.gameUI.classList.remove('hidden');
    }

    hideGameUI() {
        this.gameUI.classList.add('hidden');
    }

    // Score methods
    updateScore(playerScore, opponentScore) {
        this.playerScore.textContent = playerScore;
        this.opponentScore.textContent = opponentScore;
    }

    // Game status methods
    showStatus(message, duration = 2000) {
        this.gameStatus.textContent = message;
        this.gameStatus.style.opacity = 1;

        // Clear previous timeout if exists
        if (this.statusTimeout) {
            clearTimeout(this.statusTimeout);
        }

        // Hide status after duration
        if (duration > 0) {
            this.statusTimeout = setTimeout(() => {
                this.gameStatus.style.opacity = 0;
            }, duration);
        }
    }

    // Error handling
    showError(message) {
        console.error(message);
        this.showStatus(`ERROR: ${message}`, 0);
    }

    // Reset all UI elements
    reset() {
        this.hideGameUI();
        this.hideInstructionsScreen();
        this.showMenuScreen();
        this.updateScore(0, 0);
        this.gameStatus.textContent = '';
    }
}
