// Main entry point for the 3D Pong game
import { Game } from './game.js';
import { UI } from './ui.js';

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize UI manager
    const ui = new UI();
    
    // Show loading screen initially
    ui.showLoadingScreen();
    
    // Initialize game instance
    const game = new Game(ui);
    
    // Initialize event listeners
    initEventListeners(game, ui);
    
    // Preload assets and initialize game
    game.init()
        .then(() => {
            // Hide loading screen and show menu when game is ready
            ui.hideLoadingScreen();
            ui.showMenuScreen();
        })
        .catch(error => {
            console.error('Game initialization error:', error);
            ui.showError('Failed to initialize game. Please refresh the page.');
        });
});

// Set up all event listeners
function initEventListeners(game, ui) {
    // Menu buttons
    document.getElementById('play-button').addEventListener('click', () => {
        const playerName = document.getElementById('player-name').value || 'Player';
        game.setPlayerName(playerName);
        ui.hideMenuScreen();
        ui.showGameUI();
        game.start();
    });
    
    document.getElementById('instructions-button').addEventListener('click', () => {
        ui.hideMenuScreen();
        ui.showInstructionsScreen();
    });
    
    document.getElementById('back-button').addEventListener('click', () => {
        ui.hideInstructionsScreen();
        ui.showMenuScreen();
    });
    
    // Game controls
    window.addEventListener('mousemove', (event) => {
        if (game.isRunning()) {
            game.handleMouseMove(event);
        }
    });
    
    window.addEventListener('keydown', (event) => {
        if (game.isRunning()) {
            game.handleKeyDown(event);
        }
    });
    
    // Handle window resize
    window.addEventListener('resize', () => {
        game.handleResize();
    });
}
