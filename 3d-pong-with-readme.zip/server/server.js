// Server for 3D Multiplayer Pong
const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

// Create Express app
const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));

// Add CORS headers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

// Game state
const gameState = {
    players: {},
    rooms: {},
    waitingPlayers: []
};

// Socket.io connection handler
io.on('connection', (socket) => {
    console.log(`Player connected: ${socket.id}`);
    
    // Add player to game state
    gameState.players[socket.id] = {
        id: socket.id,
        name: 'Player',
        room: null,
        ready: false
    };
    
    // Player ready event
    socket.on('playerReady', (data) => {
        const player = gameState.players[socket.id];
        
        if (!player) return;
        
        // Update player name
        player.name = data.playerName || 'Player';
        player.ready = true;
        
        console.log(`Player ready: ${player.name} (${socket.id})`);
        
        // Find opponent or add to waiting list
        findOpponent(socket);
    });
    
    // Game update event
    socket.on('gameUpdate', (data) => {
        const player = gameState.players[socket.id];
        
        if (!player || !player.room) return;
        
        const room = gameState.rooms[player.room];
        
        if (!room) return;
        
        // Get opponent socket ID
        const opponentId = room.players.find(id => id !== socket.id);
        
        if (!opponentId) return;
        
        // Forward game update to opponent
        io.to(opponentId).emit('gameUpdate', {
            opponentPaddle: data.playerPaddle,
            ball: data.ball,
            scores: data.scores
        });
    });
    
    // Game over event
    socket.on('gameOver', (data) => {
        const player = gameState.players[socket.id];
        
        if (!player || !player.room) return;
        
        const room = gameState.rooms[player.room];
        
        if (!room) return;
        
        // Notify all players in room
        io.to(player.room).emit('gameOver', {
            winner: data.winner === 'player' ? socket.id : room.players.find(id => id !== socket.id)
        });
        
        // Reset room
        delete gameState.rooms[player.room];
        
        // Reset player state
        room.players.forEach(playerId => {
            if (gameState.players[playerId]) {
                gameState.players[playerId].room = null;
                gameState.players[playerId].ready = false;
            }
        });
    });
    
    // Disconnect event
    socket.on('disconnect', () => {
        const player = gameState.players[socket.id];
        
        if (!player) return;
        
        console.log(`Player disconnected: ${player.name} (${socket.id})`);
        
        // Remove from waiting list
        const waitingIndex = gameState.waitingPlayers.indexOf(socket.id);
        if (waitingIndex !== -1) {
            gameState.waitingPlayers.splice(waitingIndex, 1);
        }
        
        // Notify opponent if in a room
        if (player.room && gameState.rooms[player.room]) {
            const room = gameState.rooms[player.room];
            const opponentId = room.players.find(id => id !== socket.id);
            
            if (opponentId) {
                io.to(opponentId).emit('playerLeft', {
                    playerName: player.name
                });
                
                // Reset opponent state
                if (gameState.players[opponentId]) {
                    gameState.players[opponentId].room = null;
                    gameState.players[opponentId].ready = false;
                }
            }
            
            // Delete room
            delete gameState.rooms[player.room];
        }
        
        // Remove player from game state
        delete gameState.players[socket.id];
    });
});

// Find opponent for player
function findOpponent(socket) {
    const player = gameState.players[socket.id];
    
    if (!player || !player.ready) return;
    
    // Check if there are waiting players
    if (gameState.waitingPlayers.length > 0) {
        // Get first waiting player
        const opponentId = gameState.waitingPlayers.shift();
        const opponent = gameState.players[opponentId];
        
        if (!opponent) return;
        
        // Create room
        const roomId = `room_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
        
        gameState.rooms[roomId] = {
            id: roomId,
            players: [socket.id, opponentId],
            created: Date.now()
        };
        
        // Update player states
        player.room = roomId;
        opponent.room = roomId;
        
        // Join room
        socket.join(roomId);
        io.sockets.sockets.get(opponentId)?.join(roomId);
        
        // Notify players
        io.to(roomId).emit('gameStart', {
            roomId: roomId,
            players: [
                { id: socket.id, name: player.name },
                { id: opponentId, name: opponent.name }
            ]
        });
        
        // Notify each player about the opponent
        socket.emit('playerJoined', {
            playerId: opponentId,
            playerName: opponent.name
        });
        
        io.to(opponentId).emit('playerJoined', {
            playerId: socket.id,
            playerName: player.name
        });
        
        console.log(`Game started in room ${roomId}: ${player.name} vs ${opponent.name}`);
    } else {
        // Add player to waiting list
        gameState.waitingPlayers.push(socket.id);
        console.log(`Player ${player.name} (${socket.id}) is waiting for an opponent`);
    }
}

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
});
