# 3D Multiplayer Pong - README

## Overview
This is a modernized 3D version of the classic Pong game with multiplayer functionality. The game is built using Three.js for 3D rendering and Socket.io for real-time multiplayer capabilities.

## Features
- 3D game environment with modern graphics
- Real-time multiplayer functionality
- Keyboard and mouse controls
- Dynamic scoring system
- Responsive design for different screen sizes
- Game lobby and player matching

## Installation

1. Extract the zip file to a directory of your choice
2. Open a terminal/command prompt in that directory
3. Install dependencies:
   ```
   npm install
   ```
4. Start the game server:
   ```
   npm start
   ```
5. Open a web browser and navigate to:
   ```
   http://localhost:3000
   ```

## How to Play

1. Enter your name on the start screen and click "PLAY GAME"
2. Use your mouse to move the paddle horizontally
3. Alternatively, use the left and right arrow keys
4. The first player to reach 10 points wins
5. The ball speeds up as the game progresses

## Multiplayer Testing

To test the multiplayer functionality locally:
1. Start the server as described above
2. Open two browser windows or tabs to http://localhost:3000
3. Enter different player names in each window
4. Click "PLAY GAME" in both windows to be matched together

## Technologies Used
- Three.js for 3D rendering
- Socket.io for real-time communication
- Express for the web server
- HTML5, CSS3, and JavaScript

## Project Structure
- `/public` - Client-side files
  - `/css` - Stylesheets
  - `/js` - JavaScript files
    - `main.js` - Entry point
    - `game.js` - Game logic and 3D rendering
    - `ui.js` - User interface management
- `/server` - Server-side files
  - `server.js` - Express and Socket.io server

## Customization
You can modify game settings in the `game.js` file under the `settings` object to adjust:
- Court dimensions
- Paddle size and speed
- Ball speed and acceleration
- Maximum score

Enjoy the game!
